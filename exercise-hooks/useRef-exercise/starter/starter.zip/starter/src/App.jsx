export const App = () => {
  return (
    <>
      <div className="fullscreen-height">
        <h1>Ref exercise starter</h1>
        <button> Click to scroll </button>
      </div>
      <div className="fullscreen-height lightblue-background">
        <h1>Hello</h1>
      </div>
    </>
  );
};

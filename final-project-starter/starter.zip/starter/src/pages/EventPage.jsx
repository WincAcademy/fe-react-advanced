import { Heading } from '@chakra-ui/react';

export const EventPage = () => {
  return <Heading>Event</Heading>;
};

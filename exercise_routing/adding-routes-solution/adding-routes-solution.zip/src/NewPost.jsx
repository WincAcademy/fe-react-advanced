export const NewPost = () => {
  return <h1>New Post</h1>;
};

export default () => {
  return (
    <div className="App">
      <h1>Prop Drilling and Component Composition</h1>
    </div>
  );
};

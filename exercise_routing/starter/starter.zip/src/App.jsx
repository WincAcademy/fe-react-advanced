import "./App.css";

function App() {
  return <div className="App">This is where our app will be.</div>;
}

export default App;

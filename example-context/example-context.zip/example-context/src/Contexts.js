import { createContext } from "react";

export const BooksBorrowedContext = createContext(null);

const App = () => {
	return (
		<div className="App">
			<h1>React Hooks Exercise Starter</h1>
		</div>
	);
};

export default App;

export const UserDetail = ({ user }) => {
	return (
		<>
			<p>{user.name}</p>
			<p>{user.email}</p>
		</>
	);
};
